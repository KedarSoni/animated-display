package com.example.animationindisplay;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Animation topanim,bottomanim,rightanim,leftanim,lefttopanim,rightbottomanim;
    ImageView image,image1,image2,image3,image4,image5;
    TextView k,e,d,a,r;





    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);


        topanim = AnimationUtils.loadAnimation(this,R.anim.top_animation);
        bottomanim = AnimationUtils.loadAnimation(this,R.anim.bottom_animation);
        rightanim = AnimationUtils.loadAnimation(this,R.anim.right_animation);
        leftanim = AnimationUtils.loadAnimation(this,R.anim.left_animation);
        lefttopanim = AnimationUtils.loadAnimation(this,R.anim.left_top_corner_animation);
        rightbottomanim = AnimationUtils.loadAnimation(this,R.anim.right_bottom_corner_animation);

/*        image = findViewById(R.id.image);
        image1 = findViewById(R.id.image1);
        image2 = findViewById(R.id.image2);
        image3 = findViewById(R.id.image3);
        image4 = findViewById(R.id.image4);
        image5 = findViewById(R.id.image5);*/



        k = findViewById(R.id.k);
        e = findViewById(R.id.e);
        d = findViewById(R.id.d);
        a = findViewById(R.id.a);
        r = findViewById(R.id.r);




/*
        image.setAnimation(topanim);
        image1.setAnimation(rightanim);
        image2.setAnimation(bottomanim);
        image3.setAnimation(leftanim);
        image4.setAnimation(lefttopanim);
        image5.setAnimation(rightbottomanim);*/
        k.setAnimation(topanim);
        e.setAnimation(rightanim);
        d.setAnimation(bottomanim);
        a.setAnimation(leftanim);
        r.setAnimation(lefttopanim);




    }


}